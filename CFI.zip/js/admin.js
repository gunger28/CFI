window.onload = function(){

const exitButton = document.getElementById("exit");
exitButton.addEventListener('click', function() {
    window.location.href = '../admin/registration.html'
})
}